%% 1.
%Consider a link for IP communications from one router to another router with a capacity of
%100 Mbps (1 Mbps = 106 bps). The link supports one flow of IP packets whose throughput
%is 80 Mbps and the IP packet sizes are exponentially distributed with an average of 800
%Bytes. The link has an associated queue of size Q (in number of packets).
%(a) Compute the average packet delay (in milliseconds) and the packet loss rate (in %)
%suffered by the flow when the queue size is Q = 8 packets. Results:
%Avg. packet delay =0.231 msec. 
%Packet loss rate 0= 3.007%

%(b) Compute the minimum queue size Q such that the packet loss rate suffered by the flow is not higher than 0.1%. Results:
%Minimum queue size = 23 packets
%Packet loss rate = 0.09481%
% a)
C = 1e8;            % em bps
throughput = 80e6;  % em bps
B = 800;            % Bytes
L = 8 * B;          % → bits por pacote
Q = 8;              % Queue tamanho
K = Q +1;

lambda = throughput / L;    % recebidos
mu = C / L;                 % trafic
rho = lambda / mu;

j = 0:K;
j = (lambda/mu) .^j;
divisor = sum(j);


taxa = (lambda/mu)^K / divisor;

loss_rate_percent = taxa* 100;


i = 0:K;
numerador = (i .* (lambda/mu).^i);
numerador = sum(numerador);
L = numerador / divisor;

W = L /(lambda*(1-taxa));


fprintf("Exercício 1\n")
fprintf('  a)\n');
fprintf('Atraso médio: %.3f ms\n', W*1000);
fprintf('Taxa de perda: %.3f%%\n', loss_rate_percent );

% b)
fprintf('  b)\n')
target_loss = 0.001; % 0.1%
Q_test = 1;
current_loss = 1;


while current_loss > target_loss
    K_test = Q_test + 1;
    current_loss = (rho^K_test * (1 - rho)) / (1 - rho^(K_test + 1));
    if current_loss > target_loss
        Q_test = Q_test + 1;
    end
end


fprintf('Mínimo Q: %d pacotes\n', Q_test);
fprintf('Taxa de perda real: %.5f%%\n', current_loss * 100);




%% 2.
%Consider a data service server such that, when the server is attending 250 simultaneous
%requests, it serves each request with an exponentially distributed time of 200 µsecs on
%average (1 µsecs = 10-6 seconds). The server receives service requests at an average rate 𝜆
%(in requests/sec) and has an acceptance limit of B simultaneous requests.
%(a) Compute the service blocking probability and the average service time per request
%when 𝜆 = 1.23 × 106 and B = 250. Results:
%Service blocking probability = 0.02888%
%Avg. service time per request = 46.389 microseconds
%(b) Plot the service blocking probability (in %) in one bar chart and the average service
%time per request (in µsecs) in another bar chart considering B = 200, 250, 300, 350 and
%400, when 𝜆 = 1.23 × 106 . What do you conclude? Results:
% a)

fprintf("2.\na)\n");

requests_simutlaneos = 250;
average = 200e-6;

B = 250;
lambda = 1.23e6;
mu = B/average;

ro = lambda  / mu;

Pb = ((1-ro) / (1-ro^(B+1))) * (ro^B);

n = 0:B;

Pn = ((1-ro) / (1-ro^(B+1))) .* (ro.^n);
L = sum(n.*Pn);
lambda_eff = lambda * (1-Pb);

T = L / lambda_eff; 

fprintf("Service blocking probability = %f%%\n", Pb* 100)
fprintf("Avg. service time per request = %.3f microseconds\n", T*1e6)

B_valores = [200, 250, 300, 350];

Pb_grafico = zeros(size(B_valores));
T_grafico = zeros(size(B_valores));

for i = 1:length(B_valores)
    B_atual = B_valores(i);
    
    % Recalcular Pb para o B atual
    Pb_atual = ((1 - ro) / (1 - ro^(B_atual + 1))) * (ro^B_atual);
    
    % Recalcular L para o B atual
    n_atual = 0:B_atual;
    Pn_atual = ((1 - ro) / (1 - ro^(B_atual + 1))) .* (ro.^n_atual);
    L_atual = sum(n_atual .* Pn_atual);
    
    % Recalcular T (em segundos)
    lambda_eff_atual = lambda * (1 - Pb_atual);
    T_atual = L_atual / lambda_eff_atual;
    
    % Guardar resultados convertidos (Pb em % e T em microsegundos)
    Pb_grafico(i) = Pb_atual * 100;
    T_grafico(i) = T_atual * 1e6;
end

figure;
subplot(2,1,1); % Divide a janela em 2 linhas, 1 coluna (Gráfico superior)
bar(categorical(B_valores), Pb_grafico, 'FaceColor', [0.8500 0.3250 0.0980]);
grid on;
ylabel('Blocking Prob. (%)');
title('Service Blocking Probability vs Acceptance Limit (B)');

% --- Gráfico 2: Average Service Time ---
subplot(2,1,2); % Gráfico inferior
bar(categorical(B_valores), T_grafico, 'FaceColor', [0 0.4470 0.7410]);
grid on;
xlabel('Acceptance Limit (B)');
ylabel('Avg. Service Time (\mu s)');
title('Average Service Time per Request vs Acceptance Limit (B)');


%% 3.
%Consider a Call Center service with m operators such that each operator attends each client
%with an exponentially distributed time of 3 minutes. The service receives requests at an
%average rate 𝜆 (in requests/hour).
%(a) Compute the probability of all operators being occupied and the average queuing time
%per request when 𝜆 = 370 and m = 20.
%Prob. of all operators occupied = 64.813%
%Avg. queuing time per request
%= 77.776 seconds
%(b) When 𝜆 = 370, compute the minimum number m of operators required so that the
%average queuing time per request is not higher than 10 seconds. For the value of m
%found, compute the probability of all operators being occupied and the average
%queuing time per request. Results:
%Minimum number of operators= 23
%Prob. of all operators occupied = 23.598%
%Avg. queuing time per request = 9.439 seconds
%(c) Plot the average queuing time per request considering 𝜆 = 320, 330, 340, 350, 360,
%370 and 380, when the number of operators is m = 20. What do you conclude? Results:
lambda = 370;
m = 20;
miu = 1 / (3 / 60); % miu = 20 pedidos/hora
racio = lambda / miu;
rho = lambda / (m * miu); % Fator de utilização (rho = 0.925)

range = 0:(m-1);
divisor = sum((racio.^range) ./ factorial(range));

termo_m = (racio^m / factorial(m)) * (1 / (1 - rho));

% P(ocupados) = termo_m / (somatório_0_to_m-1 + termo_m)
prob_ocupados = termo_m / (divisor + termo_m);

% Fórmula: Wq = P(ocupados) / (m * miu - lambda) -> resultado em horas
Wq_horas = prob_ocupados / (m * miu - lambda);
Wq_segundos = Wq_horas * 3600; % Converter horas para segundos

fprintf('Prob. of all operators occupied = %.3f%%\n', prob_ocupados * 100);
fprintf('Avg. queuing time per request = %.3f seconds\n', Wq_segundos);

% Queremos encontrar o 'm' mínimo para que Wq <= 10 segundos
Wq_limite = 10; 
m_b = ceil(lambda / miu); % Começa no mínimo teórico para o sistema ser estável (m > 18.5)
Wq_b_seg = Inf;           % Inicializar com valor alto para entrar no loop

while Wq_b_seg > Wq_limite
    m_b = m_b + 1; % Incrementa o número de operadores
    
    rho_b = lambda / (m_b * miu);
    range_b = 0:(m_b-1);
    
    % Recalcular fórmulas para o m atual
    divisor_b = sum((racio.^range_b) ./ factorial(range_b));
    termo_m_b = (racio^m_b / factorial(m_b)) * (1 / (1 - rho_b));
    
    prob_b = termo_m_b / (divisor_b + termo_m_b);
    Wq_b_seg = (prob_b / (m_b * miu - lambda)) * 3600;
end

fprintf('(b) \n');
fprintf('Minimum number of operators = %d\n', m_b);
fprintf('Prob. of all operators occupied = %.3f%%\n', prob_b * 100);
fprintf('Avg. queuing time per request = %.3f seconds\n', Wq_b_seg);

lambdas_c = 320:10:380; % Vetor com os valores de lambda pedidos
m_c = 20;               % Número fixo de operadores
Wq_resultados = zeros(size(lambdas_c)); % Vetor para guardar os tempos (Wq)

for i = 1:length(lambdas_c)
    l_atual = lambdas_c(i);
    rho_c = l_atual / (m_c * miu);
    
    % Fórmulas Erlang-C para o lambda atual
    range_c = 0:(m_c-1);
    divisor_c = sum((racio.^range_c) ./ factorial(range_c));
    
    % Nota: o racio depende do lambda atual
    racio_atual = l_atual / miu;
    divisor_c = sum((racio_atual.^range_c) ./ factorial(range_c));
    termo_m_c = (racio_atual^m_c / factorial(m_c)) * (1 / (1 - rho_c));
    
    prob_c = termo_m_c / (divisor_c + termo_m_c);
    
    % Guardar o tempo médio em fila (convertido para segundos)
    Wq_resultados(i) = (prob_c / (m_c * miu - l_atual)) * 3600;
end

% --- Desenhar o Gráfico ---
figure;
bar(lambdas_c, Wq_resultados, 'FaceColor', [0.2 0.6 0.8], 'EdgeColor', [0 0.2 0.4]);
grid on;
xlabel('\lambda - Taxa de Chegada (pedidos/hora)', 'FontSize', 11);
ylabel('Tempo Médio em Fila W_q (segundos)', 'FontSize', 11);
title('Impacto da Taxa de Chegada no Tempo de Espera (m = 20)', 'FontSize', 12);

% Mostrar a tabela de valores calculados no Command Window
disp('--- Alínea (c) ---');
disp('Resultados para o gráfico (lambda vs Wq):');
for i = 1:length(lambdas_c)
    fprintf('  lambda = %d pedidos/h -> Wq = %.3f segundos\n', lambdas_c(i), Wq_resultados(i));
end

%% 4.
%Consider a server based on a VM (Virtual Machine) provided by a Hypervisor that runs
%directly over the hardware of a physical machine. The average time between failures is 2
%years (for hardware failures), 180 days (for Hypervisor failures) and 90 days (for VM
%failures). Hardware failures are solved in 2 days (on average) but do not include software
%recovery. Hypervisor failures are solved in 6 hours (on average) and include VM recovery.
%VM failures are solved in 1 hour (on average). Assume that 1 year has 365 days.
%(a) Define in Matlab the matrix of the state transition rates (in days -1) of the Markov chain
%that allows to compute the availability of the VM. Assume states 1 (available), 2 (repair
%of hardware failure), 3 (repair of hypervisor failure) and 4 (repair of VM failure).
%Result:
%Matrix of the state transition rates:
%0 0 4.0000 24.0000
%0.0014 0 0 0
%0.0056 0.5000 0 0
%0.0111 0 0 0
%(b) Determine the server availability. Result:
%Server availability = 99.509%
%(c) Determine the MTBF (mean time between failures) in days and the MTTR (mean time
%to repair) in hours of the server. Results:
%MTBF (mean time between failures) = 55.44 days
%MTTR (mean time to repair) = 6.57 hours

lambda_h = 1/(365 * 2);     % estado 1 para 2
lambda_Hypervisor = 1/180;  % 1 para 3
lambda_VM = 1/90;           % 1 para 4

miu_h = 1/2;                % 2 para 3
miu_Hypervisor_VM = 1/(6/24);% 3 para 1
miu_VM = 1/(1/24);            % 4 para 1 
% Estados 1 2 3 4

Estado1_para = [0;lambda_h;lambda_Hypervisor;lambda_VM];
Estado2_para = [0; 0; miu_h; 0];
Estado3_para = [miu_Hypervisor_VM;0;0;0];
Estado4_para = [miu_VM; 0; 0; 0 ];

T =       [ Estado1_para, Estado2_para, Estado3_para, Estado4_para ];

Q = T;
for i = 1:4
    Q(i,i) = -sum(Q(:,i));
end

A = [Q; ones(1,4)];
x = [0;0;0;0; 1];
m = A\x;

P = m(1);
fprintf("Exercício 4\n")


fprintf("a)")
disp(T);

fprintf("b)\nServer availability = %.3f%%\n", P*100);


taxa_falha_total = lambda_VM + lambda_Hypervisor + lambda_h;

MTBF_dias = 1/ taxa_falha_total;
MTTR_dias = (MTBF_dias *(1-P))/P;

MTTF_horas = MTTR_dias * 24;

fprintf("c)\nMTBF = %.2f%%\n", MTBF_dias);
fprintf("MTTR = %.2f%%\n", MTTF_horas);

%% 5
%Consider a Data Center with the following backup strategy: one backup server is dedicated
%to each set of n primary servers, each one running different VM (Virtual Machine) servers.
%The availability on each VM server is 99.9%.
%(a) Determine the maximum value n so that the VM availability is at least 99.99%. For
%the value of n found, compute the resulting VM availability.
%Maximum value of n = 213
%Resulting VM availability = 99.9900%
%Plot the VM availability for n from 1 to 1000 primary servers. What do you conclude?
%Results:

fprintf("5\na)\n");

a_VM = .999;
b = 1;
n = 1;
target  = 0.9999;
calculated = 0;

while true
    n = n+1;
    target0 = 0;
    for i = 0: n-1
        target0 = target0 + binopdf(i,n+b,a_VM)*(i/n);
        
        
    end
    target1 = 0;
    for i = n:n+b
        target1 = target1 + binopdf(i,n+b,a_VM);
    end
    total = target1 + target0;
    if total < target
        n = n -1;
        break;
    end     
     
    
end

fprintf("Maxium value of n = %d\n", n);
fprintf("Resulting VM availability = %.4f %%\n", total * 100)

disponibilidade = zeros(1,1000);
for n = 0:1000
    
    target0 = 0;
    for i = 0: n-1
        target0 = target0 + binopdf(i,n+b,a_VM)*(i/n);
        
        
    end
    target1 = 0;
    for i = n:n+b
        target1 = target1 + binopdf(i,n+b,a_VM);
    end
    total = target1 + target0;
    
    disponibilidade(n+1) = total;
     
    
end
n = 0:1000;
disponibilidade = disponibilidade*100;

plot(n, disponibilidade)
grid on
xlabel("n")
ylabel("VM availability (%)")
