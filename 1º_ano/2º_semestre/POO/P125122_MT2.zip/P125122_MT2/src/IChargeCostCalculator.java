public interface IChargeCostCalculator {
    public double calculateChargeCost(Charge c);
}
